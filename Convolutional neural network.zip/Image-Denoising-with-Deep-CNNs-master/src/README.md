## Note:
* `nntools.py` is Neural Network tools developed for UCSD ECE285 MLIP. Copyright 2019. Charles Deledalle, Sneha Gupta, Anurag Paul, Inderjot Saggu.
